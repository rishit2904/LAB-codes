import java.util.*;

class q3 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter n and r");
        int n = sc.nextInt();
        int r = sc.nextInt();
        int ncr = fact(n) / (fact(r) * fact(n - r));
        System.out.println(n + "C" + r + " is " + ncr);
    }

    static int fact(int n) {
        int f = 1;
        for (int i = 1; i <= n; i++)
            f = f * i;
        return f;
    }
}